
import React, { useState, useEffect, useMemo } from 'react';
import { ShoppingBag, Search, ShoppingCart, Trash2, Plus, Minus, Zap, CheckCircle, ArrowRight, Loader2, Sparkles, AlertCircle } from 'lucide-react';
import { MOCK_PRODUCTS, TAX_RATE } from './constants';
import { Product, CartItem, CartProtocolStatus, ShoppingAnalytics } from './types';
import ProtocolStepper from './components/ProtocolStepper';
import { getSmartSuggestions, getNutritionInsight } from './services/gemini';

const App: React.FC = () => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [status, setStatus] = useState<CartProtocolStatus>(CartProtocolStatus.BROWSING);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<{name: string, reason: string}[]>([]);
  const [nutritionInsight, setNutritionInsight] = useState('');
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);

  // Analytics Calculation
  const analytics = useMemo((): ShoppingAnalytics => {
    const subtotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
    const tax = subtotal * TAX_RATE;
    const total = subtotal + tax;
    const itemCount = cart.reduce((acc, item) => acc + item.quantity, 0);
    return { subtotal, tax, total, itemCount };
  }, [cart]);

  // Handle adding to cart
  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(0, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }).filter(item => item.quantity > 0));
  };

  // Sync AI Insights
  useEffect(() => {
    if (cart.length > 0) {
      const fetchAI = async () => {
        setIsAiLoading(true);
        const [sugg, insight] = await Promise.all([
          getSmartSuggestions(cart, MOCK_PRODUCTS),
          getNutritionInsight(cart)
        ]);
        setSuggestions(sugg);
        setNutritionInsight(insight);
        setIsAiLoading(false);
      };
      
      const timeout = setTimeout(fetchAI, 1500); // Debounce AI calls
      return () => clearTimeout(timeout);
    } else {
      setSuggestions([]);
      setNutritionInsight('');
    }
  }, [cart]);

  // Protocol transitions
  useEffect(() => {
    if (cart.length > 0 && status === CartProtocolStatus.BROWSING) {
      setStatus(CartProtocolStatus.REVIEWING);
    } else if (cart.length === 0 && status !== CartProtocolStatus.BROWSING) {
      setStatus(CartProtocolStatus.BROWSING);
    }
  }, [cart, status]);

  const filteredProducts = MOCK_PRODUCTS.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const startCheckout = () => {
    setStatus(CartProtocolStatus.VALIDATING);
    setShowCheckoutModal(true);
    // Simulate processing
    setTimeout(() => {
      setStatus(CartProtocolStatus.PROCESSING);
      setTimeout(() => {
        setStatus(CartProtocolStatus.COMPLETED);
      }, 2000);
    }, 1500);
  };

  const resetCart = () => {
    setCart([]);
    setStatus(CartProtocolStatus.BROWSING);
    setShowCheckoutModal(false);
  };

  return (
    <div className="min-h-screen pb-20 lg:pb-0">
      <ProtocolStepper currentStatus={status} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left: Product Catalog */}
        <div className="lg:col-span-8 space-y-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Market Catalog</h1>
              <p className="text-slate-500 mt-1">Fresh items curated for your lifestyle.</p>
            </div>
            
            <div className="relative group">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5 group-focus-within:text-emerald-500 transition-colors" />
              <input 
                type="text"
                placeholder="Search products..."
                className="pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all w-full sm:w-64"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map(product => (
              <div 
                key={product.id} 
                className="bg-white rounded-2xl overflow-hidden border border-slate-100 shadow-sm hover:shadow-md transition-all group flex flex-col"
              >
                <div className="aspect-[4/3] overflow-hidden relative">
                  <img 
                    src={product.image} 
                    alt={product.name} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-2 left-2">
                    <span className="px-2 py-1 bg-white/90 backdrop-blur rounded-lg text-[10px] font-bold uppercase tracking-wider text-slate-700 shadow-sm">
                      {product.category}
                    </span>
                  </div>
                </div>
                <div className="p-5 flex-grow flex flex-col">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-semibold text-slate-800 text-lg leading-tight">{product.name}</h3>
                    <span className="font-bold text-emerald-600">${product.price.toFixed(2)}</span>
                  </div>
                  <p className="text-sm text-slate-500 line-clamp-2 mb-4 flex-grow">{product.description}</p>
                  <button 
                    onClick={() => addToCart(product)}
                    className="w-full py-2 bg-slate-900 text-white rounded-xl font-medium flex items-center justify-center gap-2 hover:bg-emerald-600 transition-colors active:scale-95 transform"
                  >
                    <Plus className="w-4 h-4" /> Add to Cart
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Cart & Insights */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Cart Card */}
          <div className="bg-white rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-100 overflow-hidden sticky top-24">
            <div className="p-6 border-b border-slate-50 bg-slate-50/50 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-emerald-100 p-2 rounded-xl text-emerald-600">
                  <ShoppingCart className="w-5 h-5" />
                </div>
                <h2 className="font-bold text-lg text-slate-800">Your Mart Cart</h2>
              </div>
              <span className="bg-emerald-100 text-emerald-700 text-xs px-2.5 py-1 rounded-full font-bold">
                {analytics.itemCount} Items
              </span>
            </div>

            <div className="max-h-[400px] overflow-y-auto p-4 custom-scrollbar">
              {cart.length === 0 ? (
                <div className="py-12 text-center">
                  <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                    <ShoppingBag className="w-8 h-8 text-slate-300" />
                  </div>
                  <p className="text-slate-400 font-medium">Your cart is currently empty</p>
                  <p className="text-xs text-slate-400 mt-1 px-8">Add fresh items from our catalog to get started.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {cart.map(item => (
                    <div key={item.id} className="flex gap-4 group">
                      <div className="w-16 h-16 rounded-xl overflow-hidden bg-slate-100 flex-shrink-0">
                        <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-grow">
                        <div className="flex justify-between items-start">
                          <h4 className="text-sm font-semibold text-slate-800">{item.name}</h4>
                          <button onClick={() => removeFromCart(item.id)} className="text-slate-300 hover:text-red-500 transition-colors">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <div className="flex justify-between items-center mt-2">
                          <div className="flex items-center border border-slate-100 rounded-lg overflow-hidden bg-slate-50">
                            <button 
                              onClick={() => updateQuantity(item.id, -1)}
                              className="p-1 px-2 hover:bg-slate-200 transition-colors text-slate-500"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="px-2 text-xs font-bold text-slate-700 w-8 text-center">{item.quantity}</span>
                            <button 
                              onClick={() => updateQuantity(item.id, 1)}
                              className="p-1 px-2 hover:bg-slate-200 transition-colors text-slate-500"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                          <span className="text-sm font-bold text-slate-700">${(item.price * item.quantity).toFixed(2)}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Smart Insights & Suggestions */}
            {cart.length > 0 && (
              <div className="px-4 pb-4 space-y-4">
                {/* AI Nutrition Banner */}
                <div className="bg-emerald-50 rounded-2xl p-4 border border-emerald-100/50">
                  <div className="flex items-center gap-2 mb-2 text-emerald-700">
                    <Zap className="w-4 h-4 fill-emerald-500" />
                    <span className="text-xs font-bold uppercase tracking-wider">Smart Protocol Insight</span>
                  </div>
                  {isAiLoading ? (
                    <div className="flex items-center gap-2 text-emerald-600/60 py-1">
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span className="text-xs">Analyzing basket for health markers...</span>
                    </div>
                  ) : (
                    <p className="text-xs text-emerald-800 leading-relaxed font-medium italic">
                      "{nutritionInsight}"
                    </p>
                  )}
                </div>

                {/* AI Suggestions List */}
                {suggestions.length > 0 && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-slate-800">
                        <Sparkles className="w-4 h-4 text-purple-500" />
                        <span className="text-xs font-bold">Recommended for You</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      {suggestions.map((s, idx) => {
                        const product = MOCK_PRODUCTS.find(p => p.name === s.name);
                        return (
                          <div key={idx} className="flex items-center justify-between p-2 bg-slate-50 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer group" onClick={() => product && addToCart(product)}>
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-lg bg-white border border-slate-100 flex items-center justify-center text-[10px] font-bold">
                                {idx + 1}
                              </div>
                              <div>
                                <p className="text-[11px] font-bold text-slate-700">{s.name}</p>
                                <p className="text-[9px] text-slate-400 font-medium truncate w-32">{s.reason}</p>
                              </div>
                            </div>
                            <button className="p-1 bg-white text-emerald-500 border border-slate-100 rounded-lg group-hover:bg-emerald-500 group-hover:text-white transition-all shadow-sm">
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Total Section */}
            <div className="p-6 bg-slate-900 text-white space-y-3">
              <div className="flex justify-between text-slate-400 text-xs">
                <span>Subtotal</span>
                <span>${analytics.subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-400 text-xs">
                <span>Tax ({(TAX_RATE * 100).toFixed(2)}%)</span>
                <span>${analytics.tax.toFixed(2)}</span>
              </div>
              <div className="pt-2 flex justify-between items-end">
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">Protocol Total</p>
                  <p className="text-2xl font-bold tracking-tight">${analytics.total.toFixed(2)}</p>
                </div>
                <button 
                  disabled={cart.length === 0}
                  onClick={startCheckout}
                  className={`px-6 py-3 rounded-xl font-bold flex items-center gap-2 shadow-lg shadow-emerald-500/20 transition-all active:scale-95 ${
                    cart.length > 0 ? 'bg-emerald-500 hover:bg-emerald-400' : 'bg-slate-700 cursor-not-allowed text-slate-500 shadow-none'
                  }`}
                >
                  Checkout <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Checkout Processing Modal / Overlay */}
      {showCheckoutModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl w-full max-w-md p-8 text-center shadow-2xl relative overflow-hidden">
            {status === CartProtocolStatus.COMPLETED && (
              <div className="absolute top-0 left-0 w-full h-1 bg-emerald-500 animate-pulse" />
            )}
            
            <div className="mb-6">
              {status === CartProtocolStatus.VALIDATING && (
                <div className="w-20 h-20 bg-amber-50 rounded-full flex items-center justify-center mx-auto">
                  <Loader2 className="w-10 h-10 text-amber-500 animate-spin" />
                </div>
              )}
              {status === CartProtocolStatus.PROCESSING && (
                <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center mx-auto">
                  <div className="relative">
                    <Loader2 className="w-10 h-10 text-blue-500 animate-spin" />
                    <ShoppingBag className="w-5 h-5 text-blue-400 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
                  </div>
                </div>
              )}
              {status === CartProtocolStatus.COMPLETED && (
                <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center mx-auto animate-bounce">
                  <CheckCircle className="w-10 h-10 text-emerald-500" />
                </div>
              )}
            </div>

            <h2 className="text-2xl font-bold text-slate-900 mb-2">
              {status === CartProtocolStatus.VALIDATING && "Validating Cart..."}
              {status === CartProtocolStatus.PROCESSING && "Finalizing Protocol..."}
              {status === CartProtocolStatus.COMPLETED && "Protocol Complete!"}
            </h2>
            
            <p className="text-slate-500 mb-8 px-4">
              {status === CartProtocolStatus.VALIDATING && "We're verifying your items and applying regional discounts."}
              {status === CartProtocolStatus.PROCESSING && "Submitting transaction to the marketplace processing layer."}
              {status === CartProtocolStatus.COMPLETED && `Success! Your order for ${analytics.itemCount} items has been secured.`}
            </p>

            {status === CartProtocolStatus.COMPLETED ? (
              <button 
                onClick={resetCart}
                className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold hover:bg-emerald-600 transition-colors shadow-lg shadow-slate-200"
              >
                Return to Shop
              </button>
            ) : (
              <div className="flex flex-col gap-3">
                <div className="flex items-center justify-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-widest">
                  <AlertCircle className="w-3.5 h-3.5" /> Secure Transaction
                </div>
                <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                  <div 
                    className={`h-full bg-emerald-500 transition-all duration-1000 ${
                      status === CartProtocolStatus.VALIDATING ? 'w-1/3' : 'w-2/3'
                    }`}
                  />
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Floating Mobile Toggle Button */}
      <div className="lg:hidden fixed bottom-6 right-6 z-40">
        <button 
          onClick={() => window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' })}
          className="bg-emerald-500 text-white p-4 rounded-full shadow-xl shadow-emerald-500/40 relative"
        >
          <ShoppingCart className="w-6 h-6" />
          {analytics.itemCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-slate-900 text-white text-[10px] font-bold w-6 h-6 rounded-full flex items-center justify-center border-2 border-emerald-500">
              {analytics.itemCount}
            </span>
          )}
        </button>
      </div>
    </div>
  );
};

export default App;
