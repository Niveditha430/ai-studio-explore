
import React from 'react';
import { CartProtocolStatus } from '../types';

interface ProtocolStepperProps {
  currentStatus: CartProtocolStatus;
}

const steps = [
  { id: CartProtocolStatus.BROWSING, label: 'Browsing' },
  { id: CartProtocolStatus.REVIEWING, label: 'Review' },
  { id: CartProtocolStatus.VALIDATING, label: 'Validation' },
  { id: CartProtocolStatus.PROCESSING, label: 'Processing' },
  { id: CartProtocolStatus.COMPLETED, label: 'Done' },
];

const ProtocolStepper: React.FC<ProtocolStepperProps> = ({ currentStatus }) => {
  const currentIndex = steps.findIndex(s => s.id === currentStatus);

  return (
    <div className="w-full py-4 px-6 bg-white border-b sticky top-0 z-40">
      <div className="flex items-center justify-between max-w-2xl mx-auto relative">
        {/* Progress Bar Background */}
        <div className="absolute top-1/2 left-0 w-full h-0.5 bg-slate-100 -translate-y-1/2" />
        
        {/* Active Progress Bar */}
        <div 
          className="absolute top-1/2 left-0 h-0.5 bg-emerald-500 transition-all duration-500 -translate-y-1/2" 
          style={{ width: `${(currentIndex / (steps.length - 1)) * 100}%` }}
        />

        {steps.map((step, idx) => {
          const isActive = idx <= currentIndex;
          const isCurrent = idx === currentIndex;

          return (
            <div key={step.id} className="relative z-10 flex flex-col items-center">
              <div 
                className={`w-4 h-4 rounded-full border-2 transition-colors duration-300 ${
                  isActive 
                    ? 'bg-emerald-500 border-emerald-500' 
                    : 'bg-white border-slate-300'
                } ${isCurrent ? 'ring-4 ring-emerald-100' : ''}`}
              />
              <span className={`text-[10px] mt-2 font-medium uppercase tracking-wider ${
                isActive ? 'text-emerald-600' : 'text-slate-400'
              }`}>
                {step.label}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ProtocolStepper;
