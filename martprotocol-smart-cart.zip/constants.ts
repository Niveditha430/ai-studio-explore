
import { Product } from './types';

export const MOCK_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Organic Avocado',
    category: 'Produce',
    price: 1.99,
    image: 'https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?auto=format&fit=crop&w=300&q=80',
    description: 'Fresh, ripe Hass avocado, perfect for toast or salads.'
  },
  {
    id: '2',
    name: 'Whole Grain Bread',
    category: 'Bakery',
    price: 3.49,
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=300&q=80',
    description: 'Hearty, slow-baked whole grain bread with a seeds topping.'
  },
  {
    id: '3',
    name: 'Greek Yogurt',
    category: 'Dairy',
    price: 4.99,
    image: 'https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&w=300&q=80',
    description: 'Creamy high-protein plain Greek yogurt.'
  },
  {
    id: '4',
    name: 'Organic Strawberries',
    category: 'Produce',
    price: 5.25,
    image: 'https://images.unsplash.com/photo-1464965911861-746a04b4bca6?auto=format&fit=crop&w=300&q=80',
    description: 'Sweet and juicy organic seasonal strawberries.'
  },
  {
    id: '5',
    name: 'Dark Chocolate 70%',
    category: 'Snacks',
    price: 2.75,
    image: 'https://images.unsplash.com/photo-1511381939415-e44015466834?auto=format&fit=crop&w=300&q=80',
    description: 'Premium fair-trade dark chocolate bar.'
  },
  {
    id: '6',
    name: 'Colombian Coffee Beans',
    category: 'Beverages',
    price: 12.99,
    image: 'https://images.unsplash.com/photo-1447933601403-0c6688de566e?auto=format&fit=crop&w=300&q=80',
    description: 'Single-origin medium roast coffee beans (500g).'
  },
  {
    id: '7',
    name: 'Almond Milk',
    category: 'Dairy Alternative',
    price: 3.99,
    image: 'https://images.unsplash.com/photo-1550583726-5165211f31fc?auto=format&fit=crop&w=300&q=80',
    description: 'Unsweetened original almond milk, vitamin enriched.'
  },
  {
    id: '8',
    name: 'Oatmeal Porridge',
    category: 'Pantry',
    price: 4.49,
    image: 'https://images.unsplash.com/photo-1517673132405-a56a62b18caf?auto=format&fit=crop&w=300&q=80',
    description: 'Old fashioned rolled oats, perfect for breakfast.'
  }
];

export const TAX_RATE = 0.0825; // 8.25%
