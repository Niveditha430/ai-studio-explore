
import { GoogleGenAI, Type } from "@google/genai";
import { CartItem, Product } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getSmartSuggestions = async (cart: CartItem[], allProducts: Product[]) => {
  if (cart.length === 0) return [];

  const cartNames = cart.map(i => i.name).join(', ');
  const availableNames = allProducts.map(p => `${p.name} (${p.category})`).join(', ');

  const prompt = `Given the items currently in a user's shopping cart: [${cartNames}]. 
  Analyze the user's shopping behavior and suggest 2-3 additional items from the following available catalog: [${availableNames}]. 
  Focus on complementary items (e.g., milk for coffee, bread for avocado). 
  Provide suggestions in JSON format with a brief "reason" for each.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              reason: { type: Type.STRING }
            },
            required: ['name', 'reason']
          }
        }
      }
    });

    const suggestions = JSON.parse(response.text || "[]");
    return suggestions;
  } catch (error) {
    console.error("Error fetching suggestions:", error);
    return [];
  }
};

export const getNutritionInsight = async (cart: CartItem[]) => {
  if (cart.length === 0) return "Add items to see nutritional insights.";

  const cartList = cart.map(i => `${i.quantity}x ${i.name}`).join(', ');
  const prompt = `Provide a very brief (2 sentences) health/nutritional summary of this grocery list: ${cartList}. Be encouraging and informative.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt
    });
    return response.text || "Insight unavailable.";
  } catch (error) {
    return "Could not load insights.";
  }
};
