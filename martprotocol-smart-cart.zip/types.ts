
export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  image: string;
  description: string;
  nutritionalInfo?: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export enum CartProtocolStatus {
  BROWSING = 'BROWSING',
  REVIEWING = 'REVIEWING',
  VALIDATING = 'VALIDATING',
  PROCESSING = 'PROCESSING',
  COMPLETED = 'COMPLETED'
}

export interface Recommendation {
  productId: string;
  reason: string;
}

export interface ShoppingAnalytics {
  subtotal: number;
  tax: number;
  total: number;
  itemCount: number;
}
